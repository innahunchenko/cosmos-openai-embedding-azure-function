# cosmos-openai-embedding-azure-function
Python Azure Function that runs every 24 hours to generate text embeddings from Cosmos DB documents using Azure OpenAI. All services are accessed securely via User-Assigned Managed Identity (UAMI) without API keys.
